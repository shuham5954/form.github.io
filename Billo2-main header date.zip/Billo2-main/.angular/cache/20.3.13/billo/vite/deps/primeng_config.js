import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-2EAFME6V.js";
import "./chunk-NJRGDI66.js";
import "./chunk-EQB33ICH.js";
import "./chunk-CYIUJTKM.js";
import "./chunk-DNIZXC5G.js";
import "./chunk-XWLXMCJQ.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
