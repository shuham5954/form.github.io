import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Aside } from '../common/theme/aside/aside';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CustomDatePickerDirective } from '../common/directive/date-picker.directive';
import { ButtonModule } from 'primeng/button';
import { Select } from 'primeng/select';
import flatpickr from 'flatpickr';

interface City {
    name: string;
    code: string;
}


@Component({
  selector: 'app-admin',
  imports: [Aside,RouterOutlet , FormsModule , CustomDatePickerDirective , FormsModule , ButtonModule,Select ],
  templateUrl: './admin.html',
  styleUrl: './admin.scss',
})
export class Admin implements OnInit , AfterViewInit {

  public salesSummaryDateRange: Date= new Date();
  ngOnInit(): void {
  }

  isShowAside:boolean = false;
  cities: City[] | undefined;
  selectedCity: City | undefined;
  ngAfterViewInit() {
  this.setDatePickerConfig();
  }

	@ViewChild('salesSummaryDateRangeTemRef') salesSummaryDateRangeTemRef!: ElementRef;

    setDatePickerConfig(){
  
        if (this.salesSummaryDateRangeTemRef) {
        // const now = new Date(current);
        // now.setHours(now.getHours() - 2);
              flatpickr(this.salesSummaryDateRangeTemRef.nativeElement, {
                enableTime: true,
                mode: "range",
                noCalendar: false,
                dateFormat: "m/d/Y, h:i K",
                time_24hr: false,
                // defaultDate: now,
                altInput: true,
                altFormat: "m/d/Y, h:i K",
                // minDate: new Date("2020-1-1"),
                // maxDate: new Date(),
                // minuteIncrement:2
        });
      } 
  
    }

toggleAside() {
  this.isShowAside  = !this.isShowAside

}
  salesSumDateChange(){
    console.log(this.salesSummaryDateRange , "start time "); 
  }

}
