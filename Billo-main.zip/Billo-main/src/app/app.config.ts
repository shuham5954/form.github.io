import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { authInterceptor } from './common/auth/auth.interceptor';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { ECHARTS_PROVIDER } from './echarts.provider';
import * as echarts from 'echarts';


export const appConfig: ApplicationConfig = {
  providers: [
    ECHARTS_PROVIDER,
    provideHttpClient(withInterceptors([authInterceptor])),
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes), provideClientHydration(withEventReplay()),
  ]
};
