import { CommonModule, NgClass} from '@angular/common';
import { Component } from '@angular/core';
import { MenuItem } from '../aside/aside.model';

@Component({
  selector: 'app-aside',
  imports: [NgClass, CommonModule ],
  templateUrl: './aside.html',
  styleUrl: './aside.scss',
})
export class Aside {
  toggleSub: boolean = false;
  userRole = 'seller'; // change to user / retail

  MENU_LIST: MenuItem[] = [
    {
      label: 'Dashboard',
      key: 'dashboard',
      roles: ['user', 'seller', 'retail'],
      iconPath:'icon/dashboard-navbar.svg',
      children: [
        { label: 'User Dashboard', key: 'userDash',iconPath:'icon/gmail-com.svg', roles: ['seller'] },
        { label: 'Seller Dashboard', key: 'sellerDash', iconPath:'icon/gmail-com.svg',  roles: ['seller'] },
        { label: 'Retail Dashboard', key: 'retailDash', roles: ['retail'] },
      ],
    },
    {
      label: 'Analysis',
      key: 'analysis',
      iconPath:'icon/gmail-com.svg',
      roles: ['seller', 'retail'],
    },
    {
      label: 'Export',
      key: 'export',
      roles: ['user', 'seller'],
      children: [
        { label: 'Excel', key: 'excel',iconPath:'icon/gmail-com.svg', roles: ['user', 'seller'] },
        { label: 'PDF', key: 'pdf',iconPath:'icon/gmail-com.svg', roles: ['seller'] },
      ],
    },
  ];

  activeParent: string | null = null;
  activeChild: string | null = null;

  hasAccess(item: MenuItem): boolean {
    return item.roles.includes(this.userRole);
  }

  onParentClick(menu: MenuItem) {
    this.activeParent = menu.key;
    this.activeChild = null;
  }

  onChildClick(parent: MenuItem, child: MenuItem) {
    this.activeParent = parent.key;
    this.activeChild = child.key;
  }

  toggleSubmenu() {
    this.toggleSub = !this.toggleSub;
  }
}
