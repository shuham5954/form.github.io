import { CommonModule, NgClass} from '@angular/common';
import { Component } from '@angular/core';
import { MenuItem } from '../aside/aside.model';

@Component({
  selector: 'app-aside',
  imports: [NgClass, CommonModule ],
  templateUrl: './aside.html',
  styleUrl: './aside.scss',
})
export class Aside {
  toggleSub: boolean = false;
  userRole = 'seller'; // change to user / retail

  MENU_LIST: MenuItem[] = [
    {
      label: 'Dashboard',
      key: 'dashboard',
      roles: ['user', 'seller', 'retail'],
      iconPath:'icon/dashboard-navbar.svg'
    },
    {
      label: 'Resturent Management',
      key: 'export',
      roles: ['user', 'seller'],
      iconPath:'icon/resturent-management-aside.svg' ,
      children: [
        { label: 'category Management', key: 'categoryManagement',iconPath:'icon/category-management-aside.svg', roles: ['user', 'seller'] },
        { label: 'Product Management', key: 'productManagement',iconPath:'icon/product-management-icon.svg', roles: ['seller'] },
        { label: 'Table Management', key: 'tableManagement',iconPath:'icon/table-management-aside.svg', roles: ['seller'] },
        { label: 'Tax And Bill Config', key: 'taxAndBillConfig',iconPath:'icon/tax-and-bill-config-aside.svg', roles: ['seller'] },
      ],
    },
     {
      label: 'Captain App',
      key: 'captainApp',
      iconPath:'icon/captain-app-aside.svg',
      roles: ['seller', 'retail'],
    },
    {
      label: 'Kitchen View',
      key: 'kitchenView',
      iconPath:'icon/kitchen-view-aside.svg',
      roles: ['seller', 'retail'],
    },
  ];

  activeParent: string | null = null;
  activeChild: string | null = null;

  hasAccess(item: MenuItem): boolean {
    return item.roles.includes(this.userRole);
  }

  onParentClick(menu: MenuItem) {
    this.activeParent = menu.key;
    this.activeChild = null;
  }

  onChildClick(parent: MenuItem, child: MenuItem) {
    this.activeParent = parent.key;
    this.activeChild = child.key;
    if(child){

    }
    else{
      
      this.toggleSub = false;
    }
  }

  
}
