import { Component, OnInit, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { NgxEchartsDirective } from 'ngx-echarts';
import * as echarts from 'echarts/core';
import { EChartsOption, BarSeriesOption } from 'echarts';

// charts
import { PieChart } from 'echarts/charts';
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components';
// renderer
// import { CanvasRenderer } from 'echarts/renderers';
import { SVGRenderer } from 'echarts/renderers';
import { log } from 'console';

echarts.use([PieChart, TitleComponent, TooltipComponent, LegendComponent, SVGRenderer]);

@Component({
  selector: 'app-admin-dashbord',
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './admin-dashbord.html',
  styleUrl: './admin-dashbord.scss',

})
export class AdminDashbord implements OnInit {
  private platformId = inject(PLATFORM_ID);
  isBrowser = isPlatformBrowser(this.platformId);
  optionsForPie: any;
  optionsForSales: any;

  //  sales start 
  rawData: number[][] = [
    [100, 302, 301, 1, 390, 330, 320],
    [320, 132, 101, 134, 90, 230, 210],
    [220, 182, 191, 234, 290, 330, 310]
  ];
  // sales end 

  totalData: number[] = [];

  series: BarSeriesOption[] = [];

  ngOnInit() {
    this.loadPieChart();
    // for sales section 
    this.calculateTotal();
    this.createSeries();
    this.loadSalesChart();
  }


  loadPieChart() {
    this.optionsForPie = {
      renderer: 'svg',
      title: {
        text: 'Bill Payout Method',
        subtext: 'Fake Data',
        left: 'center'
      },
      tooltip: {
        trigger: 'item',
        formatter: (params: any) => {
          return `${params.seriesName || 'Payed from'}<br/> ${params.marker} ${params.name}: <b>$${params.value}</b>
    `;
        }
      },
      legend: {
        orient: 'vertical',
        left: 'left'
      },
      series: [
        {
          name: 'Payed from ',
          type: 'pie',
          radius: '50%',
          data: [
            { value: 1048, name: 'CASH' },
            { value: 735, name: 'CARD' },
            { value: 580, name: 'UPI' }
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    };
  }

  loadSalesChart() {
    this.optionsForSales = {
      renderer: 'svg',
      legend: {
        selectedMode: false
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: (params: any[]) => {
          const dayIndex = params[0].dataIndex;
          const day = params[0].axisValue;

          let html = `<b>${day}</b><br/>`;

          params.forEach((item, index) => {
            const rawValue = this.rawData[index][dayIndex];
            html += `${item.marker} ${item.seriesName}: <b>${rawValue}</b><br/>`;
          });

          html += `<hr style="margin:4px 0"/>`;
          html += `<b>Total: ${this.totalData[dayIndex]}</b>`;

          return html;
        }

      },
      xAxis: {
        type: 'category',
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      },
      yAxis: {
        show: false,
        type: 'value',
        axisLabel: {
          formatter: (value: number) => `${Math.round(value * 100)}%`
        }
      },
      series: this.series
    };
  }


  private calculateTotal(): void {
    for (let i = 0; i < this.rawData[0].length; i++) {
      let sum = 0;
      for (let j = 0; j < this.rawData.length; j++) {
        sum += this.rawData[j][i];
      }
      this.totalData.push(sum);
    }
  }

  private createSeries(): void {
    const names = ['Dine in', 'Pick Up', 'Delivery'];

    this.series = names.map((name, sid) => ({
      name,
      type: 'bar',
      stack: 'total',
      barWidth: '60%',
      label: {
        show: false,
        position: 'inside',
        formatter: (params: any) => {
          const dayIndex = params.dataIndex;
          const percent =
            (params.value / this.totalData[dayIndex]) * 100;
          return percent.toFixed(1) + '%';
        }
      },
      // ✅ USE RAW VALUES (THIS FIXES BAR HEIGHT)
      data: this.rawData[sid]
    }));
  }


}
