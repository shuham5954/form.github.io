export class ResponseModel {
    public data: any = null;
    public Data: any = null;
    public status: number = 200;
    public Status: number = 200;
    public errorId: string = '';
    public exceptions: any = null;
}