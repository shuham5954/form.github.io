/** @type {import('tailwindcss').Config} */
export default {
  darkMode: false, // 🔴 OFF,
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
