import { Directive, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';
import flatpickr from 'flatpickr';

@Directive({
  selector: '[CustomDatePickerDirective]',
  standalone:true
})
export class CustomDatePickerDirective implements OnChanges {
  @Input() options: any = {}; // Accept custom options as input

  private datepicker: any;

  constructor(private readonly el: ElementRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['options'] && this.datepicker) {
      // If options change, update the Flatpickr instance
      this.datepicker.set(this.options);
    }
  }

  ngAfterViewInit() {
    this.datepicker = flatpickr(this.el.nativeElement, this.options);
  }
}