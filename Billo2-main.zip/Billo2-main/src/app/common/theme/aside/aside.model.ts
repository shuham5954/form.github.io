export class MenuItem {
  label: string = '';
  key: string = '';
  roles: string[] = [];
  iconPath?: string;
  children?: MenuItem[] = [];
}
