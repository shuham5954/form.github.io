import { AfterViewInit, Component, ElementRef, OnInit, PLATFORM_ID, ViewChild, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { NgxEchartsDirective } from 'ngx-echarts';
import * as echarts from 'echarts/core';
import { EChartsOption, BarSeriesOption } from 'echarts';
import { PieChart } from 'echarts/charts';
import { TitleComponent, TooltipComponent, LegendComponent } from 'echarts/components';
// import { CanvasRenderer } from 'echarts/renderers';
import { SVGRenderer } from 'echarts/renderers';
import { CustomDatePickerDirective } from '../../directive/date-picker.directive';
import { FormsModule } from '@angular/forms';
import flatpickr from 'flatpickr';
import { ButtonModule } from 'primeng/button';
import { Select } from 'primeng/select';

echarts.use([PieChart, TitleComponent, TooltipComponent, LegendComponent, SVGRenderer]);

interface City {
    name: string;
    code: string;
}


@Component({
  selector: 'app-admin-dashbord',
  imports: [CommonModule, NgxEchartsDirective , CustomDatePickerDirective , FormsModule , ButtonModule,Select],
  templateUrl: './admin-dashbord.html',
  styleUrl: './admin-dashbord.scss',
})
export class AdminDashbord implements OnInit , AfterViewInit {

  public salesSummaryDateRange: Date= new Date();

  cities: City[] | undefined;

    selectedCity: City | undefined;


  ngAfterViewInit() {
  this.setDatePickerConfig();
  }


  
	@ViewChild('salesSummaryDateRangeTemRef') salesSummaryDateRangeTemRef!: ElementRef;



  private platformId = inject(PLATFORM_ID);
  isBrowser = isPlatformBrowser(this.platformId);
  optionsForPie: any;
  optionsForSales: any;

  // Ratings & Reviews
  selectedPlatform: 'zomato' | 'swiggy' = 'zomato';
  
  zomatoReviews = [
    {
      id: 1,
      rating: 5,
      timeAgo: '1 day ago',
      location: 'Apna Fal (Bhayli-Barod)',
      comment: 'IT WAS VERY HOT'
    },
    {
      id: 2,
      rating: 5,
      timeAgo: '1 day ago',
      location: 'Apna Fal (Bhayli-Barod)',
      comment: ''
    },
    {
      id: 3,
      rating: 1,
      timeAgo: '2 days ago',
      location: 'Apna Fal (Bhayli-Barod)',
      comment: 'Poor service'
    }
  ];

  swiggyReviews: any[] = [];

  //  sales start
  rawData: number[][] = [
    [100, 302, 301, 1, 390, 330, 320],
    [320, 132, 101, 134, 90, 230, 210],
    [220, 182, 191, 234, 290, 330, 310],
  ];
  // sales end

  totalData: number[] = [];

  series: BarSeriesOption[] = [];

  ngOnInit() {
    this.loadPieChart();
    // for sales section
    this.calculateTotal();
    this.createSeries();
    this.loadSalesChart();

      this.cities = [
            { name: 'Last Week', code: 'LastWeek' },
            { name: 'Last 2 Day', code: 'Last2Day' },
            { name: 'Yesterday', code: 'Yesterday' },
            { name: 'Today', code: 'Today' },
            { name: 'Customize', code: 'customize' }
        ];
  }

  loadPieChart() {
  this.optionsForPie = {
    renderer: 'svg',
    title: {
      text: '',
      left: 'center',
    },

    grid: {
      left: 40,
      right: 40,
      top: 40,
      bottom: 20,
    },
    legend: {
      bottom: 0,
      left: 'center',
      orient: 'horizontal',
      itemWidth: 18,
      itemHeight: 10,
      itemGap: 20,
      textStyle: {
        fontSize: 13,
      },
    },

    tooltip: {
      trigger: 'item',
      formatter: (params: any) =>
        `${params.marker} ${params.name}: <b>₹${params.value}</b>`,
    },

    series: [
      {
        name: 'Payment Method',
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['50%', '58%'],
        avoidLabelOverlap: false,

        labelLayout: {
          hideOverlap: true,
          moveOverlap: 'shiftY',
        },

        label: {
          show: true,
          position: 'outside',
          fontSize: 13,
          formatter: (params: any) =>
            `${params.name} : ₹${params.value}`,
        },

        labelLine: {
          show: true,
          length: 10,
          length2: 7,
        },

        data: [
          { value: 1048, name: 'CASH' },
          { value: 735, name: 'CARD' },
          { value: 580, name: 'UPI' }
        ],
      },
    ],
  };
}

loadSalesChart() {
    this.optionsForSales = {
      renderer: 'svg',
      legend: {
        selectedMode: false,
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        formatter: (params: any[]) => {
          const dayIndex = params[0].dataIndex;
          const day = params[0].axisValue;

          let html = `<b>${day}</b><br/>`;

          params.forEach((item) => {
            // ✅ SKIP TOTAL SERIES
            if (item.seriesName === 'Total') return;

            const seriesIndex = ['Dine in', 'Pick Up', 'Delivery'].indexOf(item.seriesName);

            const rawValue = this.rawData[seriesIndex][dayIndex];

            html += `${item.marker} ${item.seriesName}: <b>${rawValue}</b><br/>`;
          });

          html += `<hr style="margin:4px 0"/>`;
          html += `<b>Total: ${this.totalData[dayIndex]}</b>`;

          return html;
        },
      },
      xAxis: {
        type: 'category',
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      },
      yAxis: {
        show: false,
        type: 'value',
        axisLabel: {
          formatter: (value: number) => `${Math.round(value * 100)}%`,
        },
      },
      series: this.series,
    };
  }

  private calculateTotal(): void {
    for (let i = 0; i < this.rawData[0].length; i++) {
      let sum = 0;
      for (let j = 0; j < this.rawData.length; j++) {
        sum += this.rawData[j][i];
      }
      this.totalData.push(sum);
    }
  }

  private createSeries(): void {
    const names = ['Dine in', 'Pick Up', 'Delivery'];
    const colors = ['#2563EB', '#38BDF8', '#00802fff']; // blue, sky, green

    const barSeries: BarSeriesOption[] = names.map((name, sid) => ({
      name,
      type: 'bar' as const, // ✅ FIX
      stack: 'total',
      barWidth: '60%',
      itemStyle: {
        color: colors[sid], // ✅ COLOR APPLIED HERE
      },
      label: {
        show: false,
      },
      data: this.rawData[sid],
    }));

    const totalLabelSeries: BarSeriesOption = {
      name: 'Total',
      type: 'bar' as const, // ✅ FIX
      barGap: '-100%',
      barWidth: '60%',
      itemStyle: {
        color: 'transparent',
      },
      label: {
        show: true,
        position: 'top',
        fontWeight: 'bold',
        fontSize: 12,
        formatter: (params: any) => `${this.totalData[params.dataIndex]}`,
      },
      data: this.totalData,
    };

    this.series = [...barSeries, totalLabelSeries];
  }

  setDatePickerConfig(){

     	if (this.salesSummaryDateRangeTemRef) {
			// const now = new Date(current);
			// now.setHours(now.getHours() - 2);
            flatpickr(this.salesSummaryDateRangeTemRef.nativeElement, {
              enableTime: true,
              mode: "range",
              noCalendar: false,
              dateFormat: "m/d/Y, h:i K",
              time_24hr: false,
              // defaultDate: now,
              altInput: true,
              altFormat: "m/d/Y, h:i K",
              // minDate: new Date("2020-1-1"),
              // maxDate: new Date(),
              // minuteIncrement:2
			});
		} 

  }

  salesSumDateChange(){
    console.log(this.salesSummaryDateRange , "start time "); 
  }

  // Ratings & Reviews methods
  getReviews() {
    return this.selectedPlatform === 'zomato' ? this.zomatoReviews : this.swiggyReviews;
  }

  getStarCount(star: number): number {
    const reviews = this.getReviews();
    return reviews.filter(r => r.rating === star).length;
  }

  getStarPercentage(star: number): number {
    const reviews = this.getReviews();
    if (reviews.length === 0) return 0;
    const count = this.getStarCount(star);
    return (count / reviews.length) * 100;
  }
}
